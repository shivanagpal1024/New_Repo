#!/bin/bash -e

# Global variables
readonly TEAM_NAME=$1
readonly COMMON_NAME=$2
readonly OWNER_EMAIL=$3
readonly CLUSTER=$4
readonly AWS_CA_ARN=arn:aws:acm-pca:us-east-1:361326022344:certificate-authority/6c59e823-888f-4df6-8652-c976d78d9983
readonly S3_ENDPOINT_URL="https://s3api-core.optum.com"

export BUCKET_NAME=kaas-cert-metadata

main() {

    create_team_dir() {
        mkdir -p ./$TEAM_NAME/$COMMON_NAME | true
    }

    # Generate password for thy key
    generate_password() {
        key_pass=$(openssl rand 16 -base64 | sed s/==//)
        echo $key_pass >> ./$TEAM_NAME/$COMMON_NAME/${COMMON_NAME}_keystore_pass
    }

    # Generate private key and csr
    create_csr() {
        # Change certificate OU based on environment
        if [ "$CLUSTER" == "streamit-ingestion-store-prod-ctc" ] || [ "$CLUSTER" == "streamit-ingestion-store-prod-elr" ] || [ "$CLUSTER" == "prod-kafka-rxclaims-ctc" ] || [ "$CLUSTER" == "prod-kafka-rxclaims-elr" ]; then
            OU="KaaS"
        elif [ "$CLUSTER" == "streamit-ingestion-store-dev-ctc" ] || [ "$CLUSTER" == "streamit-ingestion-store-dev-elr" ]; then
            OU="KaaS-alpha"
        else
            OU="PEP"
        fi

        local full_cn="/C=US/ST=Minnesota/L=Eden Prairie/O=Optum/OU=${OU}/CN="$COMMON_NAME
        echo "Generating cert with DN = ${full_cn}"
        openssl req -new -newkey rsa:2048 \
        -days 365 -subj "$full_cn" \
        -keyout ./$TEAM_NAME/$COMMON_NAME/aws_acm_pkey.pem \
        -passout pass:$key_pass -out ./$TEAM_NAME/$COMMON_NAME/aws_acm_csr.csr 
    }

    # Issue certificate using AWS CA 
    issue_certificate() {
        certificate_arn=$(aws acm-pca issue-certificate \
        --certificate-authority-arn $AWS_CA_ARN \
        --csr file://$TEAM_NAME/$COMMON_NAME/aws_acm_csr.csr \
        --signing-algorithm "SHA256WITHRSA" \
        --validity Value=365,Type="DAYS" \
        --idempotency-token 1234 \
        --region us-east-1 \
        --query 'CertificateArn' --output text --profile prod)
    }

    download_certificate() {
        echo $certificate_arn
        aws acm-pca get-certificate \
        --certificate-authority-arn $AWS_CA_ARN \
        --certificate-arn $certificate_arn \
        --output text \
        --region us-east-1 \
        --profile prod \
        | sed -e 's/\t/\n/g' >> ./$TEAM_NAME/$COMMON_NAME/certificate.pem
    }

    get_certificate () {
        rtn_code=1
        while [ $rtn_code -ne 0 ]; do
            sleep 3
            download_certificate
            rtn_code=$?
        done
    }

    convert_pem_to_p12() {
        openssl pkcs12 -export -in ./$TEAM_NAME/$COMMON_NAME/certificate.pem \
        -password pass:$key_pass \
        -inkey ./$TEAM_NAME/$COMMON_NAME/aws_acm_pkey.pem \
        -passin pass:$key_pass \
        -out ./$TEAM_NAME/$COMMON_NAME/keystore.p12 \
        -name $COMMON_NAME
    }

    convert_p12_to_jks() {
        keytool -importkeystore \
        -srckeypass $key_pass \
        -srcstorepass $key_pass \
        -srckeystore ./$TEAM_NAME/$COMMON_NAME/keystore.p12 \
        -srcstoretype PKCS12 \
        -srcalias $COMMON_NAME \
        -destkeystore ./$TEAM_NAME/$COMMON_NAME/$COMMON_NAME.keystore.jks \
        -deststoretype jks \
        -deststorepass $key_pass \
        -destalias $COMMON_NAME
    }

    update_s3() {
        # Pull JSON file from S3 and place into a tmp file. If no JSON file exists, create the tmp JSON file
        aws --endpoint-url $S3_ENDPOINT_URL s3 cp s3://$BUCKET_NAME/$CLUSTER-certs.json ./$CLUSTER-certs.tmp.json --profile s3 | printf "{\n\n}" > ./$CLUSTER-certs.tmp.json

        expiration_date=$(date +%F --date='+1 year')

        # Append the existing tmp JSON file with the newly created certificate info, move it back into $CLUSTER-certs.json, and re-upload to S3
        jq --arg COMMON_NAME "$COMMON_NAME" \
        --arg certificate_arn "$certificate_arn" \
        --arg key_pass "$key_pass" \
        --arg expiration_date "$expiration_date" \
        --arg email "$OWNER_EMAIL" \
        ". + {\"$COMMON_NAME\": {\"arn\": \"$certificate_arn\", \"password\": \"$key_pass\", \"expiration\": \"$expiration_date\", \"email\": \"$OWNER_EMAIL\"} }" ./$CLUSTER-certs.tmp.json \
        > tmp.$$.json && mv tmp.$$.json ./$CLUSTER-certs.json
        aws --endpoint-url $S3_ENDPOINT_URL s3 cp ./$CLUSTER-certs.json s3://$BUCKET_NAME/$CLUSTER-certs.json --profile s3
       
    }

    # Call functions here
    create_team_dir
    generate_password
    create_csr
    issue_certificate
    get_certificate
    convert_pem_to_p12
    convert_p12_to_jks
    update_s3
    bash ./script/publish_cert_to_optum_s3.sh $TEAM_NAME $COMMON_NAME $CLUSTER
}

main
