import sys
import requests
from requests.auth import HTTPBasicAuth
import time
import json
import os
import boto3
from botocore.exceptions import ClientError
import smtplib
from os import path
import argparse
import subprocess
import os

def encode(data, ignore_dicts=False):
  # if this is a unicode string, return its string representation
  if isinstance(data, unicode):
      return data.encode('utf-8')
  # if this is a list of values, return list of byteified values
  if isinstance(data, list):
      return [ encode(item, ignore_dicts=True) for item in data ]
  # if this is a dictionary, return dictionary of byteified keys and values
  # but only if we haven't already byteified it
  if isinstance(data, dict) and not ignore_dicts:
      return {
          encode(key, ignore_dicts=True): encode(value, ignore_dicts=True)
          for key, value in data.iteritems()
      }
  # if it's anything else, return it in its original form
  return data

def get_pr(org, repo, pull_number):
  token = os.environ['GITHUB_API_TOKEN']
  commit_urls = []
  committed_files = []
  base_url = 'https://github.optum.com/api/v3'
  headers = {'Authorization' : 'token ' + token}
  r = requests.get(url=base_url + '/repos/' + org + '/' + repo + '/pulls/' + pull_number, headers=headers)
  if r.status_code == 200:
    content = json.loads(r.content, object_hook=encode)
    link = content['_links']['commits']['href']
    mcs = content['merge_commit_sha']
  else:
    return {'committed_files': None, 'error_code': 1, 'error_message': 'unable to get pull request content.'}

  mcsr = requests.get(url=base_url + '/repos/' + org + '/' + repo + '/commits/' + mcs)
  if mcsr.status_code >= 200 and mcsr.status_code < 300:
    content = json.loads(mcsr.content, object_hook=encode)
    mcsr_files = [z['filename'] for z in content['files']]
    for f in content['files']:
      committed_files.append({'file': f['filename'], 'patch': f['patch']})
  else:
    print('[WARN]: unable to determine actual merge drift.')
  return {'committed_files': committed_files, 'error_code': 0, 'error_message': ''}

def getDiff(patch):
  line = ''
  lines = []
  for char in patch:
    if char != '\n':
      line = line + char
    if char == '\n':
      lines.append(line)
      line = ''
  # this is necessary to grab that last line if no newline char is at the end of the file
  if line.strip() != '':
    lines.append(line)
  previousLines = []
  changedLines = []
  for line in lines:
    if str.startswith(line, '-'):
      previousLines.append(line[1:])
    if str.startswith(line, '+'):
      changedLines.append(line[1:])
  return {'previous_lines': previousLines, 'changed_lines': changedLines}

def search(args):
  org = args.org[0]
  repo = args.repo[0]
  pr = args.pr[0]
  team = args.team[0]
  previous_topics = []
  changed_topics = []
  # keeping the track of previous and new partition
  previous_partition = []
  changed_partition = []
  partition_topic = []
  results = get_pr(org, repo, pr)
  files = results['committed_files']
  # creating dictionary to keep the values of topic and its corresponding partition
  Dict1 = {}
  Dict2 = {}
  csv = ""
  for file in files:
    csv = file['file']
    file_name = csv.split('/')[2]
    diff = getDiff(file['patch'])
    for line in diff['previous_lines']:
      line = line.strip()
      if line != '':
        previous_topics.append(line.split(',')[0].strip())
        var1 = line.split(',')[0].strip()
        var2 = line.split(',')[5].strip()
        Dict1[var1] = var2
        previous_partition.append(line.split(',')[5].strip())


    for line in diff['changed_lines']:
      line = line.strip()
      if line != '':
        changed_topics.append(line.split(',')[0].strip())
        var3 = line.split(',')[0].strip()
        var4 = line.split(',')[5].strip()
        Dict2[var3] = var4
        changed_partition.append(line.split(',')[5].strip())

  deleted_topics = [str.format("\"{}\"", t) for t in previous_topics if t not in changed_topics]

  # getting the length of dictionary
  x = len(Dict1)
  y = len(Dict2)

  # finding the intersection of two dictionary and then comparing their values.
  if x >= y :
   for key in Dict2:
     if key in Dict1:
       if(Dict1[key] == "partitions"):
         continue
       if int(Dict2[key]) < int(Dict1[key]):
         partition_topic.append(key)
  elif x < y:
   for key in Dict1:
     if key in Dict2:
       if(Dict2[key] == "partitions"):
         continue
       if int(Dict2[key]) < int(Dict1[key]):
         partition_topic.append(key)

  # getting the string
  partition_topic1 = json.dumps(partition_topic)
  partition_topic2 = partition_topic1
  partition_topic2 = partition_topic2.replace('[', '')
  partition_topic2 = partition_topic2.replace(']', '')

  # Command for removed topics
  if not deleted_topics:
    print('')
  else:
    print('kafka team will run the following command to delete topics from the team `' + team + '`' + '\n')
    print('curl -X DELETE -i --user "USER:PASS" -H "Accept: application/json" -H "Content-Type: application/json" --data \'{"team":"' + team + '", "topicsList":[' + ','.join(deleted_topics) + ']}\' http://kafka-manager.ocp-ctc-core-nonprod.optum.com/delete')

  # command for decreased Partition
  if not partition_topic2:
    print('')
  else:
    print('\n')
    print('kafka team will run the following command to delete the topics for partition decrease from the team ' + team + '\n')
    print('curl -X DELETE -i --user "USER:PASS" -H "Accept: application/json" -H "Content-Type: application/json" --data \'{"team":"' + team + '", "topicsList": ' + partition_topic1 + '}\' http://kafka-manager.ocp-ctc-core-nonprod.optum.com/delete')

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  commands_subparser = parser.add_subparsers(help='Commands Lists')
  ### Subparsers for different commands
  search_subparser = commands_subparser.add_parser('search',
      help='Lint a file and team for Kafka as a Service Automation.')

  search_subparser.set_defaults(func=search)

  search_subparser.add_argument('--pr',
        '-p',
        required=True,
        help='the pull request to validate.',
        nargs=1,
        dest='pr')
  search_subparser.add_argument('--org',
        '-o',
        required=True,
        help='the github organization to check.',
        nargs=1,
        dest='org')
  search_subparser.add_argument('--repository',
        '-r',
        required=True,
        help='the github repository to check.',
        nargs=1,
        dest='repo')
  search_subparser.add_argument('--team',
        '-t',
        required=True,
        help='the team the topics belong to.',
        nargs=1,
        dest='team')
  args = parser.parse_args()
  args.func(args)
