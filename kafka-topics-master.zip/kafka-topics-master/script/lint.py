import sys
import re
import subprocess
import requests
from requests.auth import HTTPBasicAuth
import time
import json
import os
from os import path
import argparse

PR_APPROVE='APPROVE'
PR_REQUEST_CHANGES='REQUEST_CHANGES'
PR_PENDING='PENDING'
PR_COMMENT='COMMENT'

HEADER_LINE='topic,producer-hosts,producer-cn,consumer-hosts,consumer-cn,partitions,config,email,ms-id'
HEADER_LINE1='topic,producer-hosts,producer-cn,consumer-hosts,consumer-cn,partitions,config,email,ms-id,aha-id'
HEADER_LINE2='topic,producer-hosts,producer-cn,consumer-hosts,consumer-cn,partitions,config,email,ms-id,compatibility'
HEADER_LINE3='topic,producer-hosts,producer-cn,consumer-hosts,consumer-cn,partitions,config,email,ms-id,compatibility,aha-id'


TIM_MESSAGE='Timothy of House Drahn, the first of his name, the Unturnt, King of the Kafka, Java and of the first order functions, Khal of the Great Eligibility Stream, King of the Garage, Protector of the Realm, Breaker of Blockchains, and Father of Dragons. The following files in the pull-request have been reviewed: '
  # 'The world is changed. I feel it in the water. I feel it in the earth. I smell it in the air. Much that once was is lost; for none now live who remember it. It began with the forging of the great rings: three were given to the TDPs, curious, stupidest and silliest of all beings. Seven to the Go Lords; great miners and craftsman of the heapstack halls. And nine, nine rings were gifted to the JVM, who above all else desire power. For within these rings was bound the strength and will to govern each space. But they were all of them deceived, for another ring was made: in the land of .NET Core, in the midst of Javajoe Gloom, the dark lord Tdrahn forged, in secret, a master ring to control all others. And into this ring, he poured his cruelty, his malice, and his will to dominate all life. One by one the following files were felled: ',

REVIEWER_LIST = [
  'ksoni2',
  'ntalekar',
  'msing230'
]

VALID_HEADERS=[
  'topic',
  'producer-hosts',
  'producer-cn',
  'consumer-hosts',
  'consumer-cn',
  'partitions',
  'config',
  'email',
  'ms-id',
  'compatibility',
  'aha-id'
]

VALID_COMPATIBILITY_TYPES = [
    'BACKWARD',
    'BACKWARD_TRANSITIVE', 
    'FORWARD', 
    'FORWARD_TRANSITIVE', 
    'FULL', 
    'NONE', 
    'FULL_TRANSITIVE'
]

VALID_CONFIG=[
  'cleanup.policy',
  'compression.type',
  'delete.retention.ms',
  'file.delete.delay.ms',
  'flush.messages',
  'flush.ms',
  'follower.replication.throttled.replicas',
  'index.interval.bytes',
  'leader.replication.throttled.replicas',
  'max.message.bytes',
  'message.format.version',
  'message.timestamp.difference.max.ms',
  'message.timestamp.type',
  'min.cleanable.dirty.ratio',
  'min.compaction.lag.ms',
  'max.compaction.lag.ms',
  'min.insync.replicas',
  'preallocate',
  'retention.bytes',
  'retention.ms',
  'segment.bytes',
  'segment.index.bytes',
  'segment.jitter.ms',
  'segment.ms',
  'unclean.leader.election.enable',
  'message.downconversion.enable'
]

###################################
# Get Pull-Request Data Functions #
###################################

# this was shamelessly taken from Stack Overflow credit goes to `Mirec Miskuf`
# seems like a simple solution to python 2.7's implementation of json marshalling and unmarshalling
def encode(data, ignore_dicts=False):
  # if this is a unicode string, return its string representation
  if isinstance(data, unicode):
      return data.encode('utf-8')
  # if this is a list of values, return list of byteified values
  if isinstance(data, list):
      return [ encode(item, ignore_dicts=True) for item in data ]
  # if this is a dictionary, return dictionary of byteified keys and values
  # but only if we haven't already byteified it
  if isinstance(data, dict) and not ignore_dicts:
      return {
          encode(key, ignore_dicts=True): encode(value, ignore_dicts=True)
          for key, value in data.iteritems()
      }
  # if it's anything else, return it in its original form
  return data


def get_pr(pull_number):
  token = os.environ['GITHUB_API_TOKEN']
  commit_urls = []
  committed_files = []
  base_url = 'https://github.optum.com/api/v3'
  headers = {'Authorization' : 'token ' + token}
  r = requests.get(url=base_url + '/repos/DataExternalization/kafka-topics/pulls/' + pull_number, headers=headers)
  if r.status_code == 200:
    content = json.loads(r.content, object_hook=encode)
    link = content['_links']['commits']['href']
    mcs = content['merge_commit_sha']
  else:
    return {'committed_files': None, 'error_code': 1, 'error_message': 'unable to get pull request content.'}

  mcsr = requests.get(url=base_url + '/repos/DataExternalization/kafka-topics/commits/' + mcs)
  if mcsr.status_code >= 200 and mcsr.status_code < 300:
    content = json.loads(mcsr.content, object_hook=encode)
    mcsr_files = [z['filename'] for z in content['files']]
    for f in content['files']:
      file_name = f['filename']
      file_name = file_name.split('/')[2]
      if file_name != 'prm-migrate':
        committed_files.append({'file': f['filename'], 'committer': content['commit']['committer']['name'], 'login': content['author']['login'], 'patch': f['patch']})
  else:
    print('[WARN]: Unable to determine actual merge drift')

  for file in committed_files:
    if file['committer'] != 'Github Enterprise' or file['committer'] != None:
      ur = requests.get(url=base_url + '/users/' + file['committer'])
      if ur.status_code >= 200 and ur.status_code < 300:
        continue
      else:
        print('[WARN]: could not verify user based on user name, attempting verification using email.')
        er = requests.get(url=base_url + '/users/' + file['login'])
        if er.status_code >= 200 and er.status_code < 300:
          print('[INFO]: identified user ' + file['login'] + '.')
        else:
          print('[WARN]: could not verify user.')
  committed_files = simplifyDictionary(committed_files)
  return {'committed_files': committed_files, 'error_code': 0, 'error_message': ''}

def getDiff(patch):
  line = ''
  lines = []
  for char in patch:
    if char != '\n':
      line = line + char
    if char == '\n':
      lines.append(line)
      line = ''
  # this is necessary to grab that last line if no newline char is at the end of the file
  if line.strip() != '':
    lines.append(line)
  previousLines = []
  changedLines = []
  for line in lines:
    if str.startswith(line, '-'):
      previousLines.append(line[1:])
    if str.startswith(line, '+'):
      changedLines.append(line[1:])
  for line in changedLines:
    tmp_line = line.strip()
    if tmp_line != '':
      if tmp_line == HEADER_LINE or tmp_line == HEADER_LINE1 or tmp_line == HEADER_LINE2 or tmp_line == HEADER_LINE3:
        changedLines.remove(line)
  return {'previous_lines': previousLines, 'changed_lines': changedLines}


############################
# Remove Duplicate Commits #
############################
def simplifyDictionary(committed_files):
  simple = []
  for c in committed_files:
    included = False
    for f in simple:
      if c['file'] == f['file']:
        included = True
    if not included:
      simple.append(c)
  return simple

#######################
# Lint File Functions #
#######################
def validateHeaders(line):
  headers_data = {}
  column = 1
  headers = line.split(',')
  length = len(headers)
  for header in headers:
    header = header.strip()
    if header != '' and header not in VALID_HEADERS:
      headers_data.update({column:header.strip()})
    column += 1
  return headers_data, length;

def validateHeaderSequence(line):
  header_seq = {}
  column = 1
  if line.strip() == HEADER_LINE.strip() or line.strip() == HEADER_LINE1.strip() or line.strip() == HEADER_LINE2.strip() or line.strip() == HEADER_LINE3.strip():
    pass
  else:
    header_seq.update({column:'wrong header'})
  return header_seq

def validateTopic(row, line, inFile, patch):
  bad_topic = {}
  msg = ''
  pattern = '^[a-zA-Z][a-zA-Z0-9]*([_.-][a-zA-Z0-9]+)*$'
  if line != "":
    topic = line.split(',')[0]
    if len(topic) != 0:
      if(re.search(pattern,topic)):
        pass
      else:
        msg = 'Topic name ' + topic + ' is invalid !'
        bad_topic.update({row:{'Topic':msg}})  
  return bad_topic

def validatePrincipals(row, row2, line):
  bad_syntax = {}
  bad_naming_syntax = {}
  row3="3"
  row4="4"
  line = line.strip()
  if line != "":
    producer_hosts = line.split(',')[1].split(':')
    producers = line.split(',')[2].split(':')
    consumer_hosts = line.split(',')[3].split(':')
    consumers = line.split(',')[4].split(':')
    len_producers = len(producers)
    len_producer_hosts = len(producer_hosts)
    len_consumers = len(consumers)
    len_consumer_hosts = len(consumer_hosts)
    #avoiding the edge case when there is one entry
    #Checking the cn_host and cn_name_count
    if len(consumers) == 1 or len(consumer_hosts) == 1:
      first_consumer = consumers[0]
      first_consumer_host = consumer_hosts[0]
      if not first_consumer:
       len_consumers = 0
      if not first_consumer_host:
       len_consumer_hosts = 0
    if len(producers) == 1 or len(producer_hosts) == 1:
      first_producer = producers[0]
      first_producer_host = producer_hosts[0]
      if not first_producer:
       len_producers = 0
      if not first_producer_host:
       len_producer_hosts = 0
    
    if len_producers != len_producer_hosts:
      bad_syntax.update({row:{'producers-cn':len_producers,'producer-hosts':len_producer_hosts}})
    if len_consumers != len_consumer_hosts:
      bad_syntax.update({row2:{'consumers-cn':len_consumers,'consumer-hosts':len_consumer_hosts}})
    if ''.join(producers).find('/') != -1:
      bad_naming_syntax.update({row3:{'cn naming error'}})
    if ''.join(consumers).find('/') != -1:
      bad_naming_syntax.update({row3:{'cn naming error'}})
  return bad_syntax, bad_naming_syntax;

def validateConfigs(row, line):
  bad_config = {}
  retension = {}
  line = line.strip()
  row9 = 1
  regex="^[a-zA-Z0-9\._-]{1,64}@(optum|uhc|uhg|logisticshealth|naviguard|(dl|ds)\.uhc)\.com$"
  if line != "":
    #checking email format
    emails = line.split(',')[7].split(':')
    if len(emails) != 0:
      if len(emails) != 0 and emails[0] != '':
        for email in emails:
          if(re.search(regex,email)):
            pass
          else:
            bad_config.update({row9:{'config_key':'**' + email + '**','config_value':'Email Address is invalid !'}})
            row9 = row9 + 1
    #checking config
    configs = line.split(',')[6].split(':')
    if len(configs) != 0:
      if len(configs) != 0 and configs[0] != '':
        for config in configs:
          key_val = config.split('=')
          if len(key_val) != 2:
            bad_config.update({row:{'config_key':key_val[0],'config_value':key_val[0]}})
          if len(key_val) == 2:
            if key_val[1].strip() == '':
              bad_config.update({row:{'config_key':key_val[0],'config_value':'empty'}})
          if key_val[0] not in VALID_CONFIG:
            bad_config.update({row:{'config_key':key_val[0],'config_value':'invalid config key'}})
          if key_val[0] == 'max.message.bytes' and int(key_val[1]) > 1000012:
            bad_config.update({row:{'config_key':key_val[0],'config_value':'large value ' + key_val[1]}})
  return bad_config;

def validatecompatibilityconfig(csv_header,row, line):
  compatibility_config_error = {}
  arr_header = csv_header.split(',')
  for i in range(len(arr_header)) :
    arr_header[i]=re.sub('[^A-Za-z]+','', arr_header[i])
  csv_header = ','.join(arr_header)
  if csv_header.find('compatibility') != -1 :
    com_col = list(csv_header.split(',')).index('compatibility')
    if line:
      compatibility = line.split(',')[com_col].upper().strip()
      if compatibility and compatibility not in VALID_COMPATIBILITY_TYPES:
        compatibility_config_error.update({row:{'compatibility_key':'**' + compatibility + '**','compatibility_value':'Compatibility is invalid !'}})
  return compatibility_config_error

def get_deleted_topics_function(row, team_name, pull_number):
  output = ''
  output = os.popen("python2.7 ./script/get_deleted_topics.py search --pr " + pull_number + " --org DataExternalization --repository kafka-topics --team " + team_name).read()
  output = output.strip()
  return output

def validate(inFile, patch, pull_number):
  print('[INFO]: Validating the changes')
  row = 1
  row2 = 2
  exit_code = 0
  flag_invalid_header = 0
  invalid_topic = []
  invalid_configs = []
  invalid_headers = []
  invalid_cn_name = []
  invalid_header_seq = []
  invalid_principals = []
  invalid_compatibility = []
  msg = ''
  msg2 = ''
  msg3 = ''
  x = ''
  topics_deleted = ''
  csv_header = ''
  topics_deleted = ''
  
  with open(inFile, 'r') as f:
    csv_name = inFile.split('/')[2]
    team_name = inFile.split('/')[1]
    line = f.readline()
    csv_header = line
    invalid_headers ,x = validateHeaders(line)
    invalid_header_seq = validateHeaderSequence(line)
  patch_diff = getDiff(patch)
  topics_deleted = get_deleted_topics_function(row, team_name, pull_number)

#Validating header 
  for h in invalid_headers:
    flag_invalid_header = 1
    msg += '**[ERROR]**: col ' + str(h) + ': invalid header \'' + invalid_headers[h] + '\'\n'
    exit_code = 1
    
  for h in invalid_header_seq:
    flag_invalid_header = 1
    msg2 = '**[ERROR]**: Valid Header should look like this **any one of these sequence** ' + '\n' + '`' + HEADER_LINE + '`' + '\n' + '`' +  HEADER_LINE1 + '`' + '\n' + '`' + HEADER_LINE2 + '`' + '\n' + '`'+  HEADER_LINE3 + '`'
    exit_code = 1
    
#Error for empty row
  for line in patch_diff['changed_lines']:
    if len(line) == 0:
      msg += '**[ERROR]**: Empty row present in CSV. \n'
      exit_code = 1

#Error for col count mismatch
  for line in patch_diff['changed_lines']:
    rowcheck = line.split(',')
    if len(rowcheck) !=  x:
      msg += '**[ERROR]**: No. of column in the row doesnot match the number of column in the header : ' + line + '\n'
      exit_code = 1

  for line in patch_diff['changed_lines']:
    if flag_invalid_header != 1:
      topic_check = validateTopic(row, line, inFile, patch)
      invalid_topic.append(topic_check)
      c = validateConfigs(row, line)
      invalid_configs.append(c)
      p ,p2= validatePrincipals(row, row2, line)
      compatibility_check = validatecompatibilityconfig(csv_header,row,line)
      invalid_compatibility.append(compatibility_check)
      invalid_principals.append(p)
      invalid_cn_name.append(p2)
      row+=1

  if topics_deleted:
    msg += '**[INFO]**: ' + topics_deleted + '\n'
    exit_code = 1
  for p in invalid_topic:
    for key in p:
      msg += '**[ERROR]**: ' +  p[key]['Topic'] + '\n'
      exit_code = 1
  for c in invalid_configs:
    for key in c:
      msg += ' **[ERROR]**: ' + c[key]['config_key'] + ' was found to have the following issue ' + c[key]['config_value'] + '\n'
      exit_code = 1
  for c in invalid_compatibility:
    for key in c:
      msg += ' **[ERROR]**: Compatibility type ' + c[key]['compatibility_key'] + ' is invalid. ' + '\n'
      exit_code = 1
  for p in invalid_principals:
    for key in p:
      msg += ' **[ERROR]**: Number of entries in the following fields does not match ' +  str(key) + ': ' + str(p[key]) +'\n'
      exit_code = 1
  for q in invalid_cn_name:
    for key in q:
      msg += ' **[ERROR]**: Kafka Topics is not yet migrated to PRM, Please follow the proper cn naming convention' +'\n'
      exit_code = 1
  if exit_code == 1:
    msg = msg + msg2
    return {'error_code': 1, 'error_message': msg}
  else:
    msg = msg + msg2
    return {'error_code': 0, 'error_message': msg}

##############################
# Check Identities Functions # This is an uncontrolled mess
##############################
def check_identities(file, patch, ms_id, login):
  ms_id_col = -1
  topic_col = -1
  changed_topic_ids = {}
  previous_topic_ids = {}
  unverified_msids = {}
  unauthorized_msids = {}
  new_topic_msids = {}
  ms_id_list = []
  ms_id_reviewers = []
  msg = ''
  error_code = 0
  with open(file, 'r') as f:
    headers = f.readline()
    headers = headers.strip()
    if headers != '':
      headers = headers.strip()
      header_tokens = headers.split(',')
      if len(header_tokens) < 2:
        print('**[ERROR]**: unexpected number of header columns.')
        exit(1)
      for i in range(len(header_tokens)):
        if header_tokens[i] == 'ms-id':
          ms_id_col = i
        if header_tokens[i] == 'topic' or header_tokens[i] == 'Topic':
          topic_col = i
      if ms_id_col == -1:
        print('returning because of invalid ms-id')
        return {'error_code': 1, 'error_message': 'could not identify ms-id column.'}
      if topic_col == -1:
        print('returning because of invalid topic')
        return {'error_code': 1, 'error_message': 'could not identify topic column.'}
      for line in f:
        line = line.strip()
        if line != '':
          line_tokens = line.split(',')
          msids = line_tokens[ms_id_col]
          msid_tokens = msids.split(':')
          for m in msid_tokens:
            if m != '':
              ms_id_list.append(m)
  patch_diff = getDiff(patch)
  for line in patch_diff['changed_lines']:
    line = line.strip()
    if line != '':
      line_tokens = line.split(',')
      changed_topic_ids.update({line_tokens[topic_col]: line_tokens[ms_id_col]})
  for line in patch_diff['previous_lines']:
    line = line.strip()
    if line != '':
      line_tokens = line.split(',')
      previous_topic_ids.update({line_tokens[topic_col]: line_tokens[ms_id_col]})
  for key in changed_topic_ids:
    if key in previous_topic_ids:
      changed_ms_ids = changed_topic_ids[key]
      changed_ms_ids = changed_ms_ids.strip()
      c_tokens = changed_ms_ids.split(':')
      previous_ms_ids = previous_topic_ids[key]
      previous_ms_ids = previous_ms_ids.strip()
      p_tokens = previous_ms_ids.split(':')
      for c in c_tokens:
        if c not in p_tokens:
          if key not in unverified_msids:
            c_list = []
            c_list.append(c)
            unverified_msids.update({key: c_list})
          else:
            c_list = unverified_msids[key]
            c_list.append(c)
            unverified_msids.update({key: c_list})
      if login not in p_tokens:
        if key not in unauthorized_msids:
          c_list = []
          c_list.append(login)
          unauthorized_msids.update({key: c_list})
        else:
          c_list = unauthorized_msids[key]
          c_list.append(login)
          unauthorized_msids.update({key: c_list})
    else:
      new_topic_msids.update({key: changed_topic_ids[key].strip().split(',')})
  if len(new_topic_msids) > 0:
    error_code = 2
    Dict_new = {}
    for key in new_topic_msids:
      for c in new_topic_msids[key]:
        Dict_new.setdefault(c, []).append(key)
        #msg = msg + '**[INFO]**: requesting new topic `' + key + '` with authorized ms-id `' + c + '`.\n'
    len_topic=''
    for k,v in Dict_new.items():
      len_topic=len(list(filter(None, v)))
      len_topic=str(len_topic)
      msg = msg +'**[INFO]**:Requesting ' + '**' + len_topic + '**' + ' topic with authorized ms-id ' + '**' + k + '**' +  ' in the csv \n'
  if len(unverified_msids) > 0:
    error_code = 1
    Dict_new2 = {}
    for key in unverified_msids:
      for c in unverified_msids[key]:
        Dict_new2.setdefault(c, []).append(key)
        #msg = msg + '**[WARN]**: topic `' + key + '` had a new ms-id `' + c + '` added as an authorized user.\n'
    len_topic2=''
    for k,v in Dict_new2.items():
      len_topic2=len(list(filter(None, v)))
      len_topic2=str(len_topic2)
      msg = msg +'**[WARN]**:A new ms-id' + '**' + k + '**' + ' has been added as an authorized user for ' + '**' + len_topic2 + '**' +  ' topics in the csv \n'
  if len(unauthorized_msids) > 0:
    error_code = 1
    Dict_new3 = {}
    convertedToList = list(set(ms_id_list))
    msg_2 = ''
    merged_list_dict = []
    for l in unauthorized_msids.values():
      merged_list_dict += l
    for l in unverified_msids.values():
      merged_list_dict += l
    for x in range(len(convertedToList)):
          if convertedToList[x] in set(merged_list_dict):
            pass
          else:
            msg_2 = msg_2 + ', '+ convertedToList[x]
    for key in unauthorized_msids:
      for c in unauthorized_msids[key]:
        Dict_new3.setdefault(c, []).append(key)
	#msg = msg + 'Please get comment or approval from anyone of these msid: ' + '**' + msg_2 + '**' + ' ' + '.\n' +  '**[ERROR]**: unauthorized user `' + c + '` modified topic `' + key + '`.\n'
    len_topic3=''
    for k,v in Dict_new3.items():
      len_topic3=len(list(filter(None, v)))
      len_topic3=str(len_topic3)
      msg = msg + 'Please get comment or approval from anyone of these msid: ' + '**' + msg_2 + '**' + ' ' + '.\n' +  '**[ERROR]**: `unauthorized user`' + '**' + k + '**' + '` modified `' + '**' + len_topic3 + '**' + ' topics in the csv.\n'
  ms_id_list = set(ms_id_list)
  if ms_id not in ms_id_list and login not in ms_id_list and ms_id not in REVIEWER_LIST and login not in REVIEWER_LIST:
    ms_id_reviewers = ms_id_list
  if len(ms_id_reviewers) > 0:
    error_code = 1
    if len(ms_id_reviewers) == 1 and list(ms_id_reviewers)[0].strip() == '':
      msg = msg + '**[ERROR]**: ms-id ' + login + ' not found in file `' + file + '`, and there are no reviewers in the file to request.\n'
    else:
      reviewers = [' ' + r for r in ms_id_reviewers]
      msg = msg + '**[ERROR]**: ms-id ' + login + ' not found in file, Please get comment or approval from anyone of these msid: ' + ' '.join(reviewers) + '.\n'
  return {'error_code': error_code, 'error_message': msg}

def post_status(pull_number, msg, committers, action):
  msg = msg + '\n' + '\n' + '**Note:** `INFO` level msg can be ignored and PR can be merged successfully. Incase you want to know more about the linter output, kindly visit this link https://github.optum.com/Kafka/kaas-prod#interpreting-linter-output'
  token = os.environ['GITHUB_API_TOKEN']
  base_url = 'https://github.optum.com/api/v3'
  headers = {'Authorization' : 'token ' + token}
  request_body = {'body': msg, 'event': action}
  r = requests.post(url=base_url + '/repos/DataExternalization/kafka-topics/pulls/' + pull_number + '/reviews', headers=headers, json=request_body)
  if r.status_code == 200:
      print('[INFO]: successfully posted status to pull request number ' + pull_number + '.')
  else:
      print('[WARN]: unable to post status to pull request number ' + pull_number + '. Please Replay the build')
      exit(1)

########
# Lint #
########
def lint(args):
  exit_code = 0
  teams = []
  pull_number = args.pr[0]
  base_dir = args.dir[0]
  validate_results = []
  identities_results = []
  pr_message = ''
  res = get_pr(pull_number)
  if res['error_code'] != 0:
    exit(res['error_code'])
  committed_files = res['committed_files']
  if len(committed_files) > 0:
    committers = [c['login'] for c in committed_files]
    if 'tdrahn' in committers:
      pr_message = TIM_MESSAGE
    else:
      pr_message = '**[INFO]:** Found the following csv files in this pull-request to review: '
    files_msg = ''
    for commit in committed_files:
      files_msg = files_msg + '`' + commit['file'] + '` '
    pr_message = pr_message + files_msg.strip() + '.\n'
    for commit in committed_files:
      file_tokens = commit['file'].split('/')
      teams.append(file_tokens[0])
    for commit in committed_files:
      validate_results.append(validate(commit['file'], commit['patch'], pull_number))
    for commit in committed_files:
      identities_results.append(check_identities(commit['file'], commit['patch'], commit['committer'], commit['login']))
    for i in identities_results:
      team = teams[0]
      if i['error_code'] == 2:
        pr_message = pr_message + i['error_message'] + '\n'
        exit_code = 2
      if i['error_code'] == 1:
        pr_message = pr_message + i['error_message'] + '\n'
        exit_code = 1
    for v in validate_results:
      if v['error_code'] != 0:
        pr_message = pr_message + v['error_message'] + '\n'
        exit_code = 1
    if exit_code == 0:
      pr_message1 = pr_message + '**Everything looks alright**.\n'
      seen = set()
      answer = []
      for line in pr_message1.splitlines():
        if line not in seen:
          seen.add(line)
          answer.append(line)
          msg3='\n'.join(answer)
      post_status(pull_number, msg3, committers, PR_APPROVE)
      # print("[INFO]: Calling Merge Function ")
      # merge(pull_number)
      exit(0)
    if exit_code == 1:
      seen = set()
      answer = []
      for line in pr_message.splitlines():
        if line not in seen:
          seen.add(line)
          answer.append(line)
          msg3='\n'.join(answer)
      post_status(pull_number, msg3, committers, PR_COMMENT)
      exit(0)
    if exit_code == 2:
      seen = set()
      answer = []
      for line in pr_message.splitlines():
        if line not in seen:
          seen.add(line)
          answer.append(line)
          msg3='\n'.join(answer)
      post_status(pull_number, msg3, committers, PR_COMMENT)
      exit(0)
  else:
    post_status(pull_number, 'Did not discover any csv file changes in this pull-request. Not doing anything.', [], PR_PENDING)
    exit(exit_code)

#########
# Merge #
#########

def merge(pull_number):
  token = os.environ['GITHUB_API_TOKEN']
  base_url = 'https://github.optum.com/api/v3'
  headers = {'Authorization' : 'token ' + token}
  #hitting github api to get sha value
  r2 = requests.get(url=base_url + '/repos/DataExternalization/kafka-topics/pulls/' + pull_number, headers=headers)
  content2 = json.loads(r2.content, object_hook=encode)
  sha_val = content2['head']['sha']
  merge_message = 'This pull request has been merged by exts_ci automation.'
  request_body = {'commit_message': merge_message, 'commit_title': 'merge pull request ' + pull_number + ' onto master.', 'sha': sha_val, 'merge_method': 'merge'}
  r = requests.put(url=base_url + '/repos/DataExternalization/kafka-topics/pulls/' + pull_number + '/merge', headers=headers, json=request_body)
  if r.status_code == 200:
      print('merged pull-request ' + pull_number + '.')
  else:
      print('merging of pull request ' + pull_number + ' may have been unsuccessful.')

########
# Main #
########
if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  commands_subparser = parser.add_subparsers(help='Commands Lists')
  ### Subparsers for different commands
  lint_subparser = commands_subparser.add_parser('lint',
      help='Lint a file and team for Kafka as a Service Automation.')

  lint_subparser.set_defaults(func=lint)

  lint_subparser.add_argument('--pr',
        '-p',
        required=True,
        help='the pull request to validate.',
        nargs=1,
        dest='pr')

  lint_subparser.add_argument('--base-dir',
        '-d',
        required=True,
        help='the directory to recursively search for more teams to validate against.',
        nargs=1,
        dest='dir')

  args = parser.parse_args()
  args.func(args)
