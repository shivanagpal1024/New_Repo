#!/bin/bash

# Global variables
readonly CSV_FILE_PATH=$1
readonly CLUSTER=$2
readonly TEAM_NAME=$(echo $CSV_FILE_PATH | cut -d"/" -f2 | cut -d"." -f1)
readonly EXISTING_CERTS_FILE="./existing-certs.json"
readonly S3_ENDPOINT_URL="https://s3api-core.optum.com"

export BUCKET_NAME=kaas-cert-metadata
export FILE_PATH=$CSV_FILE_PATH

# array containing existing certificate information pulled from S3
declare -a EXISTING_CERT_CNS=()

# array containing all CNs from the csv being looked at 
declare -a TEAM_CERT_CNS=()

#array containing CNs of certs that need to be created
declare -a CERTS_TO_BE_CREATED=()

main () {

    get_existing_cns() {
        # Parse JSON file in S3 for all CN's        
        aws --endpoint-url $S3_ENDPOINT_URL s3 cp s3://$BUCKET_NAME/$CLUSTER-certs.json $EXISTING_CERTS_FILE --profile s3 --quiet
        
        if [ $? != 0 ]; then
            echo "Warning : Certificate automation is not enabled for this cluster"
            exit 1
        fi
        # Get all CN's from source of truth in S3 and store in EXISTING_CERT_CNS array
        EXISTING_CERT_CNS=$(jq -r 'keys[]' $EXISTING_CERTS_FILE)   
    }

    parse_csv() {
        echo team name: $TEAM_NAME
        # Remove first line (column headers) from csv file
        tail -n +2 "$CSV_FILE_PATH" > "$CSV_FILE_PATH.tmp"
        # add newline to end of file for parsing reasons
        echo -e "\n" >> "$CSV_FILE_PATH.tmp"

        while read line; do
            producer_cn=$(echo "$line" | cut -d, -f3)
            consumer_cn=$(echo "$line" | cut -d, -f5)
            owner_msid=$(echo "$line" | cut -d, -f9)

            if [[ $producer_cn == '*' ]]; then
                echo found wildcard CN 
                producer_cn=''
            fi

            if [[ $consumer_cn == '*' ]]; then
                echo found wildcard CN
                consumer_cn=''
            fi
            
            # Check for multiple prodcuer CNs in one cell
            if [[ $producer_cn = *":"* ]]; then
                IFS=':' read -ra CN <<< "$producer_cn"
                for i in "${CN[@]]}"; do
                    TEAM_CERT_CNS+=( "$i" )                    
                done
            else
                TEAM_CERT_CNS+=( "$producer_cn" )
            fi

            # Check for multiple consumer CN's in one cell
            if [[ $consumer_cn = *":"* ]]; then
                IFS=':' read -ra CN <<< "$consumer_cn"
                for i in "${CN[@]]}"; do
                    TEAM_CERT_CNS+=( "$i" )                    
                done
            else
                TEAM_CERT_CNS+=( "$consumer_cn" )
            fi

        done <"$CSV_FILE_PATH.tmp"
    }

    # Remove any duplicate entries in an array
    remove_duplicates() {
        TEAM_CERT_CNS=($(echo "${TEAM_CERT_CNS[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))
    }

    determine_certs_to_be_created() {
        echo EXISTING_CERT_CNS: ${EXISTING_CERT_CNS[@]}
        echo TEAM_CERT_CNS: ${TEAM_CERT_CNS[@]}
        
        # Find differences between EXISTING_CERT_CNS and TEAM_CERT_CNS 
        # Store certs to be created in CERTS_TO_BE_CREATED array 
        # for i in "${TEAM_CERT_CNS[@]}"
        # do
        #     if [[ ! "${EXISTING_CERT_CNS[@]}" =~ "$i"  ]]; then
        #         CERTS_TO_BE_CREATED+=( "$i" )
        #     fi
        # done
        CERTS_TO_BE_CREATED=($(comm -13 <(printf '%s\n' "${EXISTING_CERT_CNS[@]}" | LC_ALL=C sort) <(printf '%s\n' "${TEAM_CERT_CNS[@]}" | LC_ALL=C sort)))

    }

    # Loop over CERTS_TO_BE_CREATED array and call create_certs script for each CN
    create_certs() {
        for cn in ${CERTS_TO_BE_CREATED[@]}
        do
            # Gather associated emails for the cert being created, store in array OWNER_EMAILS
            while read line; do
                emails=$(echo $line | grep $cn | cut -d, -f8 || true)
                IFS=':' read -ra TMP <<< "$emails"
                for i in "${TMP[@]}"; do
                    OWNER_EMAILS+=( "$i" )
                done
            done<"$CSV_FILE_PATH.tmp"
             # remove dupes from OWNER_EMAILS
            OWNER_EMAILS=($(echo "${OWNER_EMAILS[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))
            EMAIL_LIST=$( IFS=$':'; echo "${OWNER_EMAILS[*]}" )
            export EMAIL_LIST
            echo "Creating certificate with CN=${cn} and owner=${EMAIL_LIST}"
            bash ./script/create_cert.sh $TEAM_NAME $cn $EMAIL_LIST $CLUSTER
        done
    }

    get_existing_cns
    parse_csv
    remove_duplicates
    determine_certs_to_be_created
    if [ ${#CERTS_TO_BE_CREATED[@]} -eq 0 ]; then
        echo CERTS_TO_BE_CREATED: ${CERTS_TO_BE_CREATED[@]}
        echo "No new certificates to be created"
    else
        echo "Found new certificates to be created"
        echo CERTS_TO_BE_CREATED: ${CERTS_TO_BE_CREATED[@]}
        create_certs
    fi
}

main
