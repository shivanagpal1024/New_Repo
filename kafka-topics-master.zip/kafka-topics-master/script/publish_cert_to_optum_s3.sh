#!/bin/bash -e

readonly TEAM_NAME=$1
readonly COMMON_NAME=$2
readonly CLUSTER=$3
readonly S3_ENDPOINT_URL="https://s3api-core.uhc.com"
readonly TRUSTSTORE_DOWNLOAD_URL="https://repo1.uhc.com/artifactory/generic-local/com/optum/exts/pep-generic-truststore.jks"

main() {

    cleanup_folder() {
        rm -f ./$TEAM_NAME/$COMMON_NAME/aws_acm_csr.csr
        rm -f ./$TEAM_NAME/$COMMON_NAME/aws_acm_pkey.pem
        rm -f ./$TEAM_NAME/$COMMON_NAME/*.json
        rm -f ./$TEAM_NAME/$COMMON_NAME/*.p12
        rm -f ./$TEAM_NAME/$COMMON_NAME/*.pem
        rm -f ./$TEAM_NAME/$COMMON_NAME/*.csv
        rm -f ./$TEAM_NAME/$COMMON_NAME/*.tmp
    }

    # Download truststore from artifactory, change password to randomly generated string
    download_truststore() {
        # Download truststore from artifactory and change file name to kaas-truststore.jks
        wget --no-verbose -P ./$TEAM_NAME/$COMMON_NAME $TRUSTSTORE_DOWNLOAD_URL && \
        mv ./$TEAM_NAME/$COMMON_NAME/pep-generic-truststore.jks ./$TEAM_NAME/$COMMON_NAME/kaas-truststore.jks

        # generate random password for truststore and save to file
        truststore_pass=$(openssl rand 16 -base64 | sed s/==//)
        echo $truststore_pass >> ./$TEAM_NAME/$COMMON_NAME/truststore_pass

        # change truststore password
        keytool -storepasswd -storepass password -keystore ./$TEAM_NAME/$COMMON_NAME/kaas-truststore.jks -new $truststore_pass
    }

    zip_folder() {
        zip -r ./$TEAM_NAME/$COMMON_NAME{.zip,}
    }

    copy_zip_to_s3() {
        aws --endpoint-url $S3_ENDPOINT_URL --profile s3 \
        s3 cp ./$TEAM_NAME/$COMMON_NAME.zip s3://$CLUSTER/$TEAM_NAME/$COMMON_NAME.zip
    }

    generate_signed_url() {
        # 604800 seconds = 7 day expiration
        url=$(aws --endpoint-url $S3_ENDPOINT_URL --profile s3 \
        s3 presign s3://$CLUSTER/$TEAM_NAME/$COMMON_NAME.zip --expires-in 604800)
        # echo $url
    }

    send_email() {
        IFS=':' read -ra emails <<< "$EMAIL_LIST"
        for i in "${emails[@]}"; do
            echo Sending certificate $COMMON_NAME to $i
            echo -e "Thank you for using KaaS! Please download your certificate from the provided URL. The URL will expire in 7 days. If you aren't sure why you are receiving a new certificate, please see https://github.optum.com/Kafka/kafka/blob/master/README.md#certificate-migration. \nDownload URL:\n ${url}" | \
                /usr/bin/mailx -v -s "Kafka - Kafka as a Service renewed certificate:  ${COMMON_NAME}" \
                -S smtp=smtp://mailo2.uhc.com:25 \
                -S from="kafka-support_DL@ds.uhc.com" \
                $i
        done
    }

    cleanup_folder
    download_truststore
    zip_folder
    copy_zip_to_s3
    generate_signed_url
    send_email
}

main
