import os
import argparse
from os import listdir
from string import join
import requests
from requests.auth import HTTPBasicAuth
import json
import sys

TOPIC_MANAGER_URL='http://kafka-manager.ocp-ctc-core-nonprod.optum.com/'
CLUSTER_LIST=['kaas', 'kaas-prod-elr', 'kaas-prod-ctc', 'df', 'elr', 'ctc', 'voyager-stage', 'lab', 'pdp-prod-elr', 'pdp-prod-ctc', 'pdp-stage', 'epim-prod-ctc', 'epim-prod-elr', 'orx-dev', 'rlh-prod', 'rlh-dev', 'hemi-dev', 'hemi-prod', 'ebaasenc-prod', 'ebaasenc-lab', 'ebaas-lab', 'hemi-lab', 'ebaasenc-mnr', 'mnr-prod', 'mnr-02-prod', 'streamit-ingestion-store-dev-ctc', 'streamit-ingestion-store-dev-elr', 'streamit-ingestion-store-prod-ctc', 'streamit-ingestion-store-prod-elr', 'rxclaims-prod-ctc', 'rxclaims-prod-elr', 'ebaasenc-rxclaims', 'rxclaims-prod-azure', 'iris-prod-azure', 'ebaasenc-prod-shared', 'azure-prod-shared', 'rlh-lab-azure', 'ecp-lab-azure', 'azure-lab-hcc-kaas-central-01','rxclaims-claim-prod-azure', 'cosmos-dev-elr-claas', 'cosmos-dev-ctc-claas', 'cosmos-prod-elr-claas', 'cosmos-prod-ctc-claas', 'nice-dev-elr-claas', 'nice-dev-ctc-claas', 'nice-prod-elr-claas', 'nice-prod-ctc-claas', 'claims360-prod-azure', 'hcp-prod-azure']
ORGS={
    'kaas-prod':',OU=KaaS,O=Optum,L=Eden Prairie,ST=Minnesota,C=US',
    'kaas':',OU=KaaS-alpha,O=Optum,L=Eden Prairie,ST=Minnesota,C=US',
    'pep':',OU=PEP,O=Optum,L=Eden Prairie,ST=Minnesota,C=US',
    'DE':',OU=Data Externalization,O=UnitedHealth Group Inc.,L=Plymouth,ST=Minnesota,C=US'
    }

def delete_topics(args):
    headers = {'Content-Type': 'application/json'}
    headers.update({'Accept': 'application/json'})
    request_body = {'team': args.team[0], 'topics': {}}
    topics_request = []
    user = args.user
    if ':' not in user[0]:
        print('Invalid user and password. Format is \'user:pass\'. This shiz basic, yo.')
        sys.exit()
    u,p = user[0].split(':')
    for topic in args.topics:
        topics_request.append(topic)
    request_body.update({'topics':topics_request})
    if args.url:
        url = args.url[0]
        if not url.endswith("/"):
            url += "/"
    else:
        url = TOPIC_MANAGER_URL
    request = requests.delete(
        url + 'delete',
        data=json.dumps(request_body),
        auth=HTTPBasicAuth(u, p),
        headers=headers
    )
    print(request)

def team_handler(args):
    headers = {'Content-Type': 'application/json'}
    headers.update({'Accept': 'application/json'})
    request_body = {'teamName':args.team[0], 'serverCluster': args.cluster[0], 'organization': ORGS[args.org[0]], 'prefixFiles': []}
    prefix_request = []
    user = args.user
    if ':' not in user[0]:
        print('Invalid user and password. Format is \'user:pass\'.')
        sys.exit()
    u,p = user[0].split(':')
    for prefix in args.prefixes:
        if '=' not in prefix:
            print('Given prefix file, %s, does not contain a known prefix. Format for prefixes is \'key=value\', attempting creation of target file object with unknown prefix type.' % prefix)
            print('prefix: unknown, url: %s' % (prefix))
            prefix_request.append({'prefix': 'unknown', 'url': prefix})
        else:
            k,v = prefix.split('=')
            print('prefix: %s, url: %s' % (k, v))
            prefix_request.append({'prefix': k, 'url': v})
    request_body.update({'prefixFiles':prefix_request})
    if args.url:
        url = args.url[0]
        if not url.endswith("/"):
            url += "/"
    else:
        url = TOPIC_MANAGER_URL
    request = requests.post(
        url + 'team',
        data=json.dumps(request_body),
        auth=HTTPBasicAuth(u, p),
        headers=headers
    )
    print(request)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    commands_subparser = parser.add_subparsers(help='Commands Lists')
    ### Subparsers for different commands
    team_subparser = commands_subparser.add_parser('team',
        help='Add/Update a team\'s metadata including cluster, organization, and prefixes and files.')

    team_subparser.set_defaults(func=team_handler)

    delete_subparser = commands_subparser.add_parser('delete',
        help='Deletes a topic and its corresponding ACLs from the given team.')

    delete_subparser.set_defaults(func=delete_topics)

    ### Add subparser specific options
    team_subparser.add_argument('--user',
        '-u', required=True,
        help='The user used to authenticate with the application.',
        nargs=1,
        dest='user')

    team_subparser.add_argument('--exec',
        '-e',
        required=True,
        help='Add or Delete from a team.',
        nargs=1,
        choices=['add','delete'],
        dest='exec')

    team_subparser.add_argument('--team',
        required=True,
        help='The team to whom the topic belongs.',
        nargs=1,
        dest='team')

    team_subparser.add_argument('--cluster',
        '-c',
        required=True,
        help='The cluster where the team is located.',
        nargs=1,
        choices=CLUSTER_LIST,
        dest='cluster')

    team_subparser.add_argument('--org',
        '-o',
        required=True,
        help='The url of the Topic Manager application.',
        nargs=1,
        choices=ORGS.keys(),
        dest='org')

    team_subparser.add_argument('--prefix-files',
        nargs='*',
        dest='prefixes')

    team_subparser.add_argument('--url',
        help='The url of the Topic Manager application.',
        nargs=1,
        dest='url')

    ### Delete subparser specific options
    delete_subparser.add_argument('-t',
        '--topics',
        nargs='+',
        dest='topics')

    delete_subparser.add_argument('--team',
        '-c', required=True,
        help='The cluster where the team is located.',
        nargs=1,
        dest='team')

    delete_subparser.add_argument('--user',
        '-u', required=True,
        help='The user used to authenticate with the application.',
        nargs=1,
        dest='user')

    delete_subparser.add_argument('--url',
        help='The url of the Topic Manager application.',
        nargs=1,
        dest='url')

    args = parser.parse_args()
    args.func(args)
